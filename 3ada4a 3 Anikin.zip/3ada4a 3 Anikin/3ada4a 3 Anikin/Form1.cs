﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _3ada4a_3_Anikin
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int Plus;
        int Mesya;
        int Procent;
        int Vivod;
        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string textPlus = textBox1.Text;
            int p = Convert.ToInt32(textPlus);

            string textmMesya = textBox2.Text;
            int TT = Convert.ToInt32(textBox2.Text);
            int TTT = TT / 12;
            int t = TTT + 1;

            string textProcent = textBox3.Text;
            int n = Convert.ToInt32(textProcent);

            int Sum = p + p * n * t / 100;
            textBox4.Text = Convert.ToString(Sum);

        }
    }
}
