﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Auto_Anikin
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
                pictureBox1.Image = Image.FromFile(@"C:\Users\Михаил\Desktop\Машины\premium.jpg");
            label2.Text = ("1 000 000 рублей");
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox2.Checked)
                pictureBox1.Image = Image.FromFile(@"C:\Users\Михаил\Desktop\Машины\Spoiler.jpg");
            label2.Text = ("1 255 900 рублей");
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox3.Checked)
                pictureBox1.Image = Image.FromFile(@"C:\Users\Михаил\Desktop\Машины\Tune.jpg");
            label2.Text = ("1 400 000 рублей");
        }
    }
}
